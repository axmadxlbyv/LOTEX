# LOTEX SHOP

Telegram UC shop starter built with Python, Aiogram 3, SQLAlchemy async and PostgreSQL.

## Features in this starter
- 10-button customer menu
- Admin-only panel
- UC packages and prices are empty until an admin adds them
- Order request flow (game/player ID + package selection)
- Manual fulfillment: admin marks an order as completed after delivering UC
- PostgreSQL persistence
- Environment-based secrets; `.env` is excluded from Git
- Docker Compose deployment scaffold

## Not yet enabled
Telegram Stars payment, manual payment proof workflow, mandatory channel subscription,
referrals, editable media/content, full design editor and premium emoji support are planned
for the next development phases. Telegram clients do not support arbitrary background
colors for ordinary reply-keyboard buttons; visual styling must use supported Telegram UI
features and emoji.

## Quick start
1. Create a Telegram bot with @BotFather.
2. Copy `.env.example` to `.env`.
3. Set `BOT_TOKEN` and `ADMIN_IDS` (comma-separated numeric Telegram user IDs).
4. Run:
   ```bash
   docker compose up --build
   ```
   Or locally:
   ```bash
   python -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   alembic upgrade head
   python -m app
   ```

The initial Alembic migration is included. For local development without Docker,
set `DATABASE_URL` to a PostgreSQL async URL.

## Security
- Never commit `.env`, bot tokens, payment credentials or user data.
- Keep the GitHub repository public only for source code; use GitHub Secrets for CI/CD.
- Add a trusted admin ID before deploying.
