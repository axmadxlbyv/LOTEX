from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession
from app.config import settings
from app.db.models import Base

engine = create_async_engine(settings.database_url, pool_pre_ping=True)
Session = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)

async def init_db():
    # Alembic owns schema changes; this only verifies DB connectivity.
    async with engine.begin() as conn:
        await conn.run_sync(lambda connection: None)
